package org.africalib.gallery.backend.dto;

import lombok.Getter;

@Getter
public class POrderDto {

    private String name;
    private String address;
    private String payment;
    private String cardNumber;
    private String pitems;
}
